package com.handsomexi.firstxposed;

import android.app.Application;

import com.google.gson.Gson;
import com.handsomexi.firstxposed.util.ShareUtil;
import com.handsomexi.firstxposed.util.WebUtil;

public class Myapp extends Application {
    public static Application ins;
    public static Gson gson;
    @Override
    public void onCreate() {
        super.onCreate();
        ins = this;
        gson = new Gson();
        WebUtil.init();
        ShareUtil.init(this);
    }
}
