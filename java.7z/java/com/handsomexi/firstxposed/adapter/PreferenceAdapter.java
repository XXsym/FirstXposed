package com.handsomexi.firstxposed.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Switch;
import android.widget.TextView;

import com.handsomexi.firstxposed.R;

import java.util.ArrayList;
import java.util.List;

public class PreferenceAdapter extends BaseAdapter {
    private final List<Data> mData;
    private final LayoutInflater inflater;
    public PreferenceAdapter(List<Data> mData, LayoutInflater inflater) {
        this.mData = new ArrayList<>(mData);
        this.inflater = inflater;
    }
    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Data getItem(int i) {
        return mData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if (view == null) {
            view = inflater.inflate(R.layout.item_mainlist,null);
            holder = new ViewHolder(view);
            view.setTag(holder);
        }else
            holder = (ViewHolder) view.getTag();
        holder.bind(getItem(position));
        return view;
    }
    private class ViewHolder {

        private final TextView titleText;
        private final TextView subTitleText;
        private final Switch aSwitch;

        public ViewHolder(View view) {
            titleText = view.findViewById(R.id.item_title);
            subTitleText = view.findViewById(R.id.item_subTitle);
            aSwitch = view.findViewById(R.id.item_sw);
        }

        public void bind(Data data) {
            if (data == null) {
                return;
            }
            if (data.isSelection) {
                aSwitch.setVisibility(View.VISIBLE);
            } else {
                aSwitch.setVisibility(View.GONE);
            }
            aSwitch.setChecked(data.sS);
            titleText.setText(data.title);
            subTitleText.setText(data.subTitle);
        }
    }

    public static class Data {

        public String title;
        public String subTitle;
        public boolean isSelection;
        public boolean sS;

        public Data(String title, String subTitle) {
            this(title, subTitle, false, false);
        }

        public Data(String title, String subTitle, boolean isSelection, boolean selectionState) {
            this.title = title;
            this.subTitle = subTitle;
            this.isSelection = isSelection;
            this.sS = selectionState;
        }
    }
}
