package com.handsomexi.firstxposed.util;

import android.widget.Toast;

import com.handsomexi.firstxposed.Myapp;

public class ToastUtil {
    private static Toast toast;
    public static void toast(String s){
        if(toast == null)
            toast = Toast.makeText(Myapp.ins,s,Toast.LENGTH_SHORT);
        else
            toast.setText(s);
        toast.show();
    }
}
