package com.handsomexi.firstxposed.util;

import android.os.Environment;
import android.util.Log;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Config2 {
    public static File file = new File(Environment.getExternalStorageDirectory(),"ACEnergy");
    public static File settingFile;
    public static SetBean bean;
    public static String ip;
    private static Gson gson = new Gson();

    public static void init(){

        if(!file.exists()) file.mkdirs();
        settingFile = new File(file,"setting");
        if(!settingFile.exists()){
            bean = new SetBean();
        }else {
            settingFile2Bean();
        }
        //check();

    }
    //获取bean
    private static void settingFile2Bean(){
        try {

            FileReader fileReader = new FileReader(settingFile);
            BufferedReader reader = new BufferedReader(fileReader);
            String tmp;
            StringBuilder builder = new StringBuilder();
            while ((tmp = reader.readLine())!=null){
                builder.append(tmp);
            }
            fileReader.close();
            reader.close();
            String json = EncryptUtil.decrypt(builder.toString());
            bean = gson.fromJson(json,SetBean.class);
        } catch (IOException e) {
            bean = new SetBean();
            Log.e("Config","file2BeanError:"+e.getMessage());
        }
    }
    public static void check(){
        if(bean.vt<new Date().getTime()&&(bean.stealWhite || bean.recEnergy)){
            bean.stealWhite = false;
            bean.recEnergy = false;
            save();
        }
    }

    //保存bean
    public static boolean save(){
        String json = gson.toJson(bean);
        try {
            FileWriter fileWriter = new FileWriter(settingFile,false);
            fileWriter.write(json);
            fileWriter.flush();
            fileWriter.close();
            return true;
        } catch (IOException e) {
            Log.e("Config","save:"+e.getMessage());
            return false;
        }
    }


    //总开关
    public static boolean setB1(boolean b){
        bean.steal = b;
        return save();
    }
    //帮助收取开关
    public static boolean setB2(boolean b){
        bean.help = b;
        return save();
    }
    //白名单开关
    public static boolean setB3(boolean b){
        bean.stealWhite = b;
        return save();
    }
    //能量记录开关
    public static boolean setB4(boolean b){
        bean.recEnergy = b;
        return save();
    }

    public static class SetBean{
        public String name = "未登录";
        public String pasd = "";
        public long vt = 0;
        public boolean steal = true;
        public boolean help = false;
        public boolean stealWhite = false;
        public boolean recEnergy = false;
        public List<String> whiteList = new ArrayList<>();
    }
}
