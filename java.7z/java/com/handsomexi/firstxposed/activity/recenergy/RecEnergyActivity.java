package com.handsomexi.firstxposed.activity.recenergy;

import android.app.Activity;
import android.os.Bundle;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.LineData;
import com.handsomexi.firstxposed.R;

import java.util.Calendar;

public class RecEnergyActivity extends Activity {
    LineChart chart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rec);
        setChart();
    }

    private void setChart(){
        chart = findViewById(R.id.main_chart);
        ChartUtil.setChart(chart);
        LineData data = new LineData();
        data.addDataSet(DataUtil.getDateSet(Calendar.getInstance(),0,0));
        data.addDataSet(DataUtil.getDateSet(Calendar.getInstance(),0,1));
        chart.setData(data);
    }
}

