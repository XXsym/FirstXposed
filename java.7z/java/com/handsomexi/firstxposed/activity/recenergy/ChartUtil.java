package com.handsomexi.firstxposed.activity.recenergy;

import android.graphics.Color;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.handsomexi.firstxposed.R;
import com.handsomexi.firstxposed.view.MyMarkerView;

public class ChartUtil {
    static void setChart(LineChart chart){
        //设置动画
        chart.animateX(3000);
        //设置makeview
        chart.setMarker(new MyMarkerView(chart.getContext(),R.layout.markerview));
        //设置X轴
        XAxis xAxis = chart.getXAxis();
        xAxis.setDrawLabels(true);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawAxisLine(true);
        xAxis.setDrawGridLines(false);
        //设置左边Y轴
        YAxis left = chart.getAxisLeft();
        left.setAxisMinimum(0);
        //设置右边Y轴
        YAxis right = chart.getAxisRight();
        right.setEnabled(false);
        //设置Description
        Description description = new Description();
        description.setEnabled(false);
        chart.setDescription(description);
        //是否设置网格线
        chart.setDrawGridBackground(false);
        //设置背景
        chart.setBackgroundColor(Color.WHITE);
        //设置是否可以拖动
        chart.setDragEnabled(true);
        //设置是否可以放大
        chart.setDoubleTapToZoomEnabled(false);
        chart.setPinchZoom(false);
        //设置触摸事件
        chart.setTouchEnabled(true);
    }
}
