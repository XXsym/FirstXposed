package com.handsomexi.firstxposed.activity.recenergy;

import android.graphics.Color;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineDataSet;
import com.handsomexi.firstxposed.activity.recenergy.BeanUtil;
import com.handsomexi.firstxposed.bean.Bean;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DataUtil {
    public static LineDataSet getDateSet(Calendar c,int ymd,int type){
        LineDataSet dataSet = new LineDataSet(getEntrys(c,ymd,type),type==0?"偷取能量":"帮助收取能量");
        int color = type == 0?Color.parseColor("#49c970"):Color.parseColor("#1890ff");
        dataSet.setDrawCircles(true);//设置是否绘制曲线值的圆点
        dataSet.setDrawCircleHole(false);//设置曲线值的圆点是实心还是空心 false为实心
        dataSet.setMode(LineDataSet.Mode.LINEAR);//设置为曲线
        dataSet.setDrawFilled(false);//设置折线图填充
        dataSet.setValueTextSize(0);//设置字体大小
        dataSet.setLineWidth(2f);//设置线的宽度
        dataSet.setColor(color);
        dataSet.setCircleColor(color);
        return dataSet;
    }
    private static List<Entry> getEntrys(Calendar c,int ymd,int type){
        List<Entry> entries = new ArrayList<>();
        int max = BeanUtil.getMaxDay(c);
        for (int i = 1; i <= max; i++) {
            c.set(c.get(Calendar.YEAR),c.get(Calendar.MONTH),i);
            List<Bean> beans = BeanUtil.getBeanList(c,0);
            int count = BeanUtil.getCount(beans,type);
            Entry entry = new Entry(i,count);
            entry.setData(type);
            entries.add(entry);
        }
        return entries;
    }
}
