package com.handsomexi.firstxposed.activity.recenergy;

import android.util.Log;

import com.handsomexi.firstxposed.Myapp;
import com.handsomexi.firstxposed.bean.Bean;
import com.handsomexi.firstxposed.util.Config2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
 public class BeanUtil {
    //0天 1月 2年
    static List<Bean> getBeanList(Calendar calendar, int t){
        switch (t){
            case 0:{
                String name = Config2.file.getPath()+"/"+getFileName(calendar);
                return getFromFile(new File(name));
            }
            case 1:{
                int max = getMaxDay(calendar);
                List<Bean> beans = new ArrayList<>();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                for (int i = 1; i <= max; i++) {
                    beans.addAll(getFromFile(new File(getFileName(year,month,i))));
                }
                return beans;
            }
            case 2:{
                List<Bean> beans = new ArrayList<>();
                for (int i = 0; i < 12; i++) {
                    calendar.set(calendar.get(Calendar.YEAR),i,1);
                    beans.addAll(getBeanList(calendar,1));
                }
                return beans;
            }
            default:return new ArrayList<>();
        }
    }

    private static String getFileName(Calendar calendar){
        return String.valueOf(calendar.get(Calendar.YEAR)) +
                int2Str(calendar.get(Calendar.MONTH) + 1) +
                int2Str(calendar.get(Calendar.DAY_OF_MONTH)) +
                ".txt";
    }
    private static String getFileName(int y, int m, int d){
        return y + int2Str(m) + int2Str(d) + ".txt";
    }
    //根据文件名获取BeanList
    private static List<Bean> getFromFile(File file){
        List<Bean> beans = new ArrayList<>();
        try {
            FileReader fileReader = new FileReader(file);
            BufferedReader reader = new BufferedReader(fileReader);
            String tmp;
            while ((tmp = reader.readLine())!=null){
                Bean bean = Myapp.gson.fromJson(tmp,Bean.class);
                if(bean!=null) beans.add(bean);
            }
            fileReader.close();
            reader.close();
            return beans;
        } catch (IOException e) {
            Log.e("getFromFileERROR",e.getMessage()) ;
            return beans;
        }
    }
    //整形变量转字符串
    private static String int2Str(int i){
        return i<10?"0"+i:""+i;
    }
    //获取当前月最大天数
    public static int getMaxDay(Calendar calendar){
        Calendar calendar1 = Calendar.getInstance();
        calendar1.set(calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH)+1,1);
        calendar1.add(Calendar.DATE,-1);
        return calendar1.get(Calendar.DAY_OF_MONTH);
    }

    public static int getCount(List<Bean> beans,int type){
        int count = 0;
        for (Bean bean:beans){
            if(bean.type == type)
                count += bean.energy;
        }
        return count;
    }
    //获取最近一个月所有的用户
    public static List<String> getAMonthUniqueUserList(){
        List<String> strings = new ArrayList<>();
        for (int i = 0;i<31;i++){
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DATE,i*-1);
            List<Bean> beans = getBeanList(calendar,0);
            for (Bean b:beans){
                if(b!=null&&!strings.contains(b.user))
                    strings.add(b.user);
            }
        }
        return strings;
    }
}
