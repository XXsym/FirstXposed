/*
package com.handsomexi.firstxposed.activity;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import com.handsomexi.firstxposed.R;
import com.handsomexi.firstxposed.activity.recenergy.BeanUtil;
import com.handsomexi.firstxposed.util.Config2;

import java.util.ArrayList;
import java.util.List;


public class WhiteListActivity extends AppCompatActivity {
    ListView listView;
    EditText editText;
    WhiteAdapter adapter;
    List<String> whiteList = Config2.bean.whiteList;
    List<String> allNames = BeanUtil.getAMonthUniqueUserList();
    List<WBean> showNames = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_white);
        //初始化控件
        listView = findViewById(R.id.white_list);
        editText = findViewById(R.id.white_search);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                getShowNames(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
        //初始化数组
        if(whiteList == null) whiteList = new ArrayList<>();
        for (String white:whiteList){
            if(!allNames.contains(white)){
                allNames.add(white);
            }
        }
        adapter = new WhiteAdapter();
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
            WBean bean = showNames.get(position);
            bean.check = !bean.check;
            if(bean.check){
                whiteList.add(bean.name);
            }else {
                whiteList.remove(bean.name);
            }
            adapter.notifyDataSetChanged();
        });
        getShowNames(editText.getText().toString());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Config2.save();
    }

    private void getShowNames(String query){
        showNames.clear();
        for (String s:allNames){
            if(s.contains(query)||query.length()==0)
                if(whiteList.contains(s))
                    showNames.add(0,new WBean(s,true));
                else
                    showNames.add(new WBean(s,false));
        }
        adapter.notifyDataSetChanged();
    }
    class WhiteAdapter extends BaseAdapter{
        @Override
        public int getCount() {
            return showNames.size();
        }

        @Override
        public Object getItem(int i) {
            return showNames.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup parent) {
            Holder holder;
            if(null == view){
                view = getLayoutInflater().inflate(R.layout.item_whitelist,null);
                holder = new Holder(view);
                view.setTag(holder);
            }else holder = (Holder) view.getTag();
            WBean bean = showNames.get(i);
            holder.aSwitch.setChecked(bean.check);
            holder.name.setText(bean.name);
            return view;
        }
        class Holder{
            TextView name;
            Switch aSwitch;
            Holder(View view){
                name = view.findViewById(R.id.white_item_name);
                aSwitch = view.findViewById(R.id.white_item_switch);
            }
        }
    }
    class WBean{
        String name;
        boolean check;

        WBean(String name, boolean check) {
            this.name = name;
            this.check = check;
        }
    }
}
*/
