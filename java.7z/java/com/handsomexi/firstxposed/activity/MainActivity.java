/*
package com.handsomexi.firstxposed.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.handsomexi.firstxposed.R;
import com.handsomexi.firstxposed.activity.recenergy.RecEnergyActivity;
import com.handsomexi.firstxposed.adapter.PreferenceAdapter;
import com.handsomexi.firstxposed.util.AutoCollectUtils;
import com.handsomexi.firstxposed.util.Config2;
import com.handsomexi.firstxposed.util.ToastUtil;
import com.handsomexi.firstxposed.view.util.ViewUtil;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    ListView listView;
    private List<PreferenceAdapter.Data> mSetDataList = new ArrayList<>();
    private PreferenceAdapter mListAdapter;

    private final String T2 = "收取能量总开关";
    private final String T3 = "帮助好友收取能量";
    private final String T4 = "白名单模式(V)";
    private final String T5 = "白名单配置";
    private final String T6 = "能量统计开关(V)";
    private final String T7 = "查看能量统计";
    private final String T8 = "打开蚂蚁森林";
    private final String T9 = "捐赠";
    private final String T10 = "说明";
    private final String T11 = "领红包";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.main_list);
        Config2.init();
        initView();
        checkMA();
        //autoLogin(false);
    }
    private void initView(){
        mSetDataList.add(new PreferenceAdapter.Data(T2,"",true,Config2.bean.steal));
        mSetDataList.add(new PreferenceAdapter.Data(T3,"帮助好友收取快要消失的能量",true,Config2.bean.help));
        mSetDataList.add(new PreferenceAdapter.Data(T4,"白名单内的好友能量不收取\\请先开启'能量统计'以更新列表",true,Config2.bean.stealWhite));
        mSetDataList.add(new PreferenceAdapter.Data(T5,subList(Config2.bean.whiteList)));
        mSetDataList.add(new PreferenceAdapter.Data(T6,"记录每次偷取\\帮助收取详情到本地",true,Config2.bean.recEnergy));
        mSetDataList.add(new PreferenceAdapter.Data(T7,"查看偷取\\帮助收取能量统计(年、月)"));
        mSetDataList.add(new PreferenceAdapter.Data(T8,""));
        mSetDataList.add(new PreferenceAdapter.Data(T11,"最近水很大"));
        mSetDataList.add(new PreferenceAdapter.Data(T9,"请我喝未来星"));
        mSetDataList.add(new PreferenceAdapter.Data(T10,"有问题酷安给我留言"));
        mListAdapter = new PreferenceAdapter(mSetDataList,getLayoutInflater());
        listView.setAdapter(mListAdapter);
        listView.setOnItemClickListener(this);
    }
    private void checkMA(){
        if(!isModuleActive3()){
            ToastUtil.toast("模块未激活");
        }
    }
    private boolean isModuleActive3(){
        return false;
    }
*/
/*
    @Override
    protected void onResume() {
        super.onResume();
        updataView();
    }*//*


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        PreferenceAdapter.Data data = mListAdapter.getItem(position);
        switch (data.title){
            case T2:{
                if(Config2.setB1(!data.sS)){
                    data.sS = !data.sS;
                    mListAdapter.notifyDataSetChanged();
                    ToastUtil.toast("重启支付宝生效");
                }else {
                    ToastUtil.toast("设置失败");
                }
                break;
            }
            case T3:{
                if(Config2.setB2(!data.sS)){
                    data.sS = !data.sS;
                    mListAdapter.notifyDataSetChanged();
                    ToastUtil.toast("重启支付宝生效");
                }else {
                    ToastUtil.toast("设置失败");
                }
                break;
            }
            case T4:{
                if(Config2.setB3(!data.sS)){
                    data.sS = !data.sS;
                    mListAdapter.notifyDataSetChanged();
                    ToastUtil.toast("重启支付宝生效");
                }else {
                    ToastUtil.toast("设置失败");
                }
                break;
            }
            case T5:{
                startActivity(new Intent(this,WhiteListActivity.class));
                break;
            }
            case T6:{
                if(Config2.setB4(!data.sS)){
                    data.sS = !data.sS;
                    mListAdapter.notifyDataSetChanged();
                    ToastUtil.toast("重启支付宝生效");
                }else {
                    ToastUtil.toast("保存配置失败");
                }
                break;
            }
            case T7:{
                startActivity(new Intent(this,RecEnergyActivity.class));
                break;
            }
            case T8:{
                AutoCollectUtils.startAlipay(this);
                break;
            }
            case T9:{
                try {
                    startActivity(Intent.parseUri("intent://platformapi/startapp?saId=10000007&" +
                            "clientVersion=3.7.0.0718&qrcode=https%3A%2F%2Fqr.alipay.com%2FFKX06388UKNC5RZBY6EEA8%3F_s" +
                            "%3Dweb-other&_t=1472443966571#Intent;" +
                            "scheme=alipayqr;package=com.eg.android.AlipayGphone;end", Intent.URI_INTENT_SCHEME));
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
                break;
            }
            case T10:{
                startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.coolapk.com/apk/com.handsomexi.firstxposed")));
                break;
            }
            case T11:{
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=https://qr.alipay.com/c1x05493dcjupysjctvdscd"));
                intent.addCategory("android.intent.category.BROWSABLE");
                startActivity(intent);
                break;
            }
        }

    }
    */
/*public void updataView(){
        mSetDataList.get(0).title = Config2.bean.name;
        mSetDataList.get(0).subTitle = getType();
        mSetDataList.get(3).sS = Config2.bean.stealWhite;
        mSetDataList.get(5).sS = Config2.bean.recEnergy;
        mListAdapter.notifyDataSetChanged();
    }*//*

*/
/*

    public void autoLogin(boolean now){
        if(now || !Config2.bean.name.equals("未登录")&&ShareUtil.getShouldAutoLogin()){
            WebUtil.get(Config2.ip +"login?mail="+Config2.bean.name+"&pasd="+Config2.bean.pasd, new WebUtil.VolleyCallBack() {
                @Override
                public void onResponse(String res) {
                    WebBean bean = Myapp.gson.fromJson(res,WebBean.class);
                    if(bean.status == 501 ||bean.status == 502){
                        Config2.bean = new Config2.SetBean();
                        Config2.save();
                    }else if(bean.status == 200){
                        Config2.bean.vt = bean.data.vipdate;
                        Config2.check();
                    }
                    ShareUtil.putLastAutoLogin();
                    updataView();
                }
                @Override
                public void onErrorResponse(VolleyError error) { }
            });
        }
    }
    private static String getType(){
        long time = Config2.bean.vt-new Date().getTime();
        if(time<0)
            return "状态:过期";
        else {
            int aday = 86400000;
            int ahour = 3600000;
            int day = (int) (time/aday);
            time %= aday;
            int hour = (int) (time/ahour);
            return "状态:剩余"+day+"天"+hour+"时";
        }
    }
*//*


    private static String subList(List<String> strings){
        String s = strings.toString();
        s = s.substring(1,s.length()-1);
        if(s.length()>30) s = s.substring(0,30)+"...";
        else s = s+"...";
        return s;
    }
*/
/*
    @Override
    public void onLoginInputComplete(WebBean.DataBean bean) {
        Config2.updata(bean);
        updataView();
    }*//*

}
*/
