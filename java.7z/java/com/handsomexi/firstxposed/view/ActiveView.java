/*
package com.handsomexi.firstxposed.view;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.android.volley.VolleyError;
import com.handsomexi.firstxposed.Myapp;
import com.handsomexi.firstxposed.R;
import com.handsomexi.firstxposed.activity.MainActivity;
import com.handsomexi.firstxposed.bean.WebBean;
import com.handsomexi.firstxposed.util.Config2;
import com.handsomexi.firstxposed.util.ToastUtil;
import com.handsomexi.firstxposed.util.WebUtil;

import androidx.annotation.Nullable;

public class ActiveView extends DialogFragment implements View.OnClickListener {
    private EditText editText;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //设置背景透明
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return super.onCreateView(inflater, container, savedInstanceState);
    }
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view= LayoutInflater.from(getActivity()).inflate(R.layout.layout_active, null);

        editText = view.findViewById(R.id.act_et);
        view.findViewById(R.id.act_close).setOnClickListener(this);
        view.findViewById(R.id.act_jh).setOnClickListener(this);
        view.findViewById(R.id.act_buy).setOnClickListener(this);
        view.findViewById(R.id.act_exit).setOnClickListener(this);

        builder.setView(view);
        return builder.create();
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.act_close:{
                dismiss();
                break;
            }
            case R.id.act_jh:{
                String jhm = editText.getText().toString();
                if(TextUtils.isEmpty(jhm)){
                    ToastUtil.toast("卡密不能为空");
                    return;
                }
                WebUtil.get(Config2.ip+"active?mail="+Config2.bean.name+"&sec="+jhm, new WebUtil.VolleyCallBack() {
                    @Override
                    public void onResponse(String res) {
                        WebBean bean = Myapp.gson.fromJson(res,WebBean.class);
                        ToastUtil.toast(bean.message);
                        if(bean.status == 200){
                            ((MainActivity)getActivity()).autoLogin(true);
                            dismiss();
                        }
                    }

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        ToastUtil.toast("网络连接失败:"+error.getMessage());
                    }
                });
                break;
            }
            case R.id.act_buy:{
                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.zlfaka.com/links/50C66C62"));
                startActivity(intent);
                dismiss();
                break;
            }
            case R.id.act_exit:{
                Config2.bean = new Config2.SetBean();
                Config2.save();
                ((MainActivity)getActivity()).updataView();
                dismiss();
                break;
            }
        }
    }
}
*/
