package com.handsomexi.firstxposed.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.utils.MPPointF;
import com.handsomexi.firstxposed.R;

@SuppressLint("ViewConstructor")
public class MyMarkerView extends MarkerView {
    TextView textView;
    LinearLayout line;
    public MyMarkerView(Context context, int layoutResource) {
        super(context, layoutResource);
        textView = findViewById(R.id.mark_text);
        line = findViewById(R.id.mark_line);
    }

    @Override
    public void refreshContent(Entry e, Highlight highlight) {

        int x = (int)e.getX();
        int y = (int)e.getY();
        int type = (int) e.getData();
        if(y ==0 ){
            line.setVisibility(GONE);
        }else {
            line.setVisibility(VISIBLE);
        }
        if(type == 0)
            textView.setText(x+"号偷取"+y+"g能量");
        else
            textView.setText(x+"号帮助好友收取"+y+"g能量");
        super.refreshContent(e, highlight);
    }

    @Override
    public MPPointF getOffset() {
        return new MPPointF(-(getWidth() / 2),-getHeight());
    }
}
