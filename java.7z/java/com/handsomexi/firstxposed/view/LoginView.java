package com.handsomexi.firstxposed.view;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.android.volley.VolleyError;
import com.handsomexi.firstxposed.Myapp;
import com.handsomexi.firstxposed.R;
import com.handsomexi.firstxposed.bean.WebBean;
import com.handsomexi.firstxposed.util.Config2;
import com.handsomexi.firstxposed.util.EncryptUtil;
import com.handsomexi.firstxposed.util.ToastUtil;
import com.handsomexi.firstxposed.util.WebUtil;

import androidx.annotation.Nullable;

public class LoginView extends DialogFragment implements View.OnClickListener {
    private EditText mailedit;
    private EditText pasdedit;
    private Button btn1,btn2;
    private ImageView iv;
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //设置背景透明
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view= LayoutInflater.from(getActivity()).inflate(R.layout.layout_login, null);

        iv= view.findViewById(R.id.login_iv);
        mailedit= view.findViewById(R.id.login_et1);
        pasdedit= view.findViewById(R.id.login_et2);
        btn1= view.findViewById(R.id.login_btn);
        btn2=view.findViewById(R.id.reg_btn);

        iv.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);

        builder.setView(view);
        return builder.create();
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.login_iv){
            dismiss();
            return;
        }
        String str1 = mailedit.getText().toString();
        String str2 = pasdedit.getText().toString();
        LoginInputListener listener = (LoginInputListener) getActivity();
        if(check(str1,str2)){
            String str3 = EncryptUtil.MD5(str2);
            String m = v.getId() == R.id.login_btn?"login":"reg";
            WebUtil.get(Config2.ip + m+"?mail="+str1+"&pasd="+str3, new WebUtil.VolleyCallBack() {
                @Override
                public void onResponse(String res) {
                    WebBean bean = Myapp.gson.fromJson(res,WebBean.class);
                    ToastUtil.toast(bean.message);
                    if(bean.status == 200){
                        listener.onLoginInputComplete(bean.data);
                        dismiss();
                    }
                }
                @Override
                public void onErrorResponse(VolleyError error) {
                    ToastUtil.toast("网络连接失败:"+error.getMessage());
                }
            });
        }
    }

    private static boolean check(String mail, String pasd){
        boolean match = mail.matches("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$");
        if(!match){
            ToastUtil.toast("邮箱不符合");
            return false;
        }
        if(TextUtils.isEmpty(pasd)){
            ToastUtil.toast("密码不能为空");
            return false;
        }
        return true;
    }

    public interface LoginInputListener{
        void onLoginInputComplete(WebBean.DataBean bean);
    }

}
