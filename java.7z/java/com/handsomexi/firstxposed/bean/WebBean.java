package com.handsomexi.firstxposed.bean;

public class WebBean {
    public int status;
    public String message;
    public DataBean data;
    public static class DataBean {
        public String mail;
        public String pasd;
        public long reg_time;
        public String reg_ip;
        public long vipdate;
        public long last_act_time;
    }
}
