package com.handsomexi.firstxposed.bean;

public class Bean {
    public long time;
    public String user;
    public int energy;
    public int type;
}
